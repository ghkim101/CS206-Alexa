#config file containing credentials for rds mysql instance
db_username = "cs206master"
db_password = "heyalexa!"
db_name = "articles"
